# The invasion of octopods, a simple space shooter.

[Play on itch.io](http://metylene.itch.io/the-invasion-of-octopods).